<a name="0.2.2"></a>

# 0.2.2 (2015-29-05)
- build v0.2.2
- fix(localStorage): parsing safety #230

<a name="0.2.1"></a>

# 0.2.1 (2015-18-05)
- build v0.2.1
- refac(common): remove depricate code
- fix(localStorage): load/save objects #225
- Fix for bug introduced in 0.2.0 boolean values that not in objects are not converted properly

<a name="0.2.0"></a>

# 0.2.0 (2015-10-05)

## Breaking Changes
- build v0.2.0
- fromJson was replaced by JSON.parse with reviver fn
- Allow multiple keys for .remove()
- Fixed wrong angular dependence version.
- docs(README): Video Tutorial
- Update Documentation
- Set individual expiry for cookies
- docs(README.md): get started
- docs(README.md): gitter badge
- Added Gitter badge
- refa(src): remove duplicated stringification of value while storing
- style(src): indentation
- fixed issue noted in issue #193
- Changes to clearAll function - accept RegExp
- add --save argument to install with bower
- docs(README.md): cookie.clearAll hash/title
- docs(README.md): expand cookie.clearAll
- Update README.md
- fix(LICENSE): update copyright year
- fix(README.md): add \n just for aesthetic
- docs(demo): better example and clearAll
- Update README.md
- fix(README.md): add badges
- Improved documentation for setStorageCookieDomain.
- Fix a minor typo in a comment
- docs(REAMME.md): version

<a name="0.1.1"></a>
# 0.1.1 (2014-10-06)


## Breaking Changes
- update your `index.html` file to reference angular-local-storage at its new
  path inside the `dist` directory `/angular-local-storage/dist/angular-local-storage.js`
